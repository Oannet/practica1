#ifndef USERPROG_PROCESS_ARGS_H
#define USERPROG_PROCESS_ARGS_H

#include <stdlib.h>
#include <stdbool.h>

void* process_args_put_in_stack (char* cmd_line, int token);

#endif /* userprog/validate-user-memory.h */
