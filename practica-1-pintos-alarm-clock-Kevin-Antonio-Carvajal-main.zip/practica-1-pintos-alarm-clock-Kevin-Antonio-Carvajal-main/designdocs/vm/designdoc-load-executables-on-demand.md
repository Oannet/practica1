# PROJECT 3: VIRTUAL MEMORY. LOAD EXECUTABLES ON DEMAND

## EQUIPO
> Pon aquí los nombres y correos electrónicos de los integrantes de tu equipo.

<Nombre_Completo> <email@domain.example>
<Nombre_Completo> <email@domain.example>

##  PRELIMINARES
> Si tienes algún comentario preliminar a tu entrega, notas para los ayudantes o extra créditos, por favor déjalos aquí.

> Por favor cita cualquier recurso offline u online que hayas consultado mientras preparabas tu entrega, otros que no sean la documentación de Pintos, las notas del curso, o el equipo de enseñanza

## PAGE TABLE MANAGEMENT

### ESTRUCTURAS DE DATOS

> B1: A cada declaración nueva o modificación de un `struct` o `struct member`, variable global o estática, `typedef` o `enum`. Agrega comentarios en el código en el que describas su propósito en 25 palabras o menos.

 R: Va directo en el código.

### ALGORITMOS

> A2: En pocos parrafos, describe tu código para acceder a los datos de una página dada almacenada en la STP (supplemental page table).


### SYNCHRONIZATION

> No hay problemas de soncronización que resolver en esta práctica.

### RATIONALE

> A5: Por qué elegiste la(s) estructura(s) de datos que seleccionaste para representar los mapeos de memoria virtual a memoria física?

